# WhatsApp-Bomb-VBScript
WhatsApp Web spammer

### Video Tutorial
https://youtu.be/k6SO6wNk_nk
