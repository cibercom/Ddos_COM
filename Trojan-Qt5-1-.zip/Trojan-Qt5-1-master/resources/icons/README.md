# Icons

NEVER USE trojan_qt5_off/direct/pac/global/advance in your project without MY PERMISSION. I HAVE FOUND OUT SOME OF THEM IS USING IT AND NO ACKNOWLEGEMENT NOR NOTIFICATION. SO DO trojan-qt5_new. and trojan-qt5.png*

没有我的授权，你不被允许在你的项目中使用trojan_qt5_off/direct/pac/global/advance等图标。我发现有些人在你的项目中使用了这些图标并且没有告诉我或贴出原出处。以上规则同样适用于trojan-qt5_new 和 trojan-qt5.png
