---
name: Bug report (English)
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

### Describe the bug

### Environment

- Trojan-Qt5 version:
- OS version:

### Steps you have tried


### What did you expect to see?


### What did you see instead?


### Config and error log in detail (with all sensitive info masked)

```
PASTE LOG HERE
```
