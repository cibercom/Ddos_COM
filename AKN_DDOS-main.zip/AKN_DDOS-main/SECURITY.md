# Security Policy

## Supported Versions

This is the only supported version right now any issue report it.

## Reporting a Vulnerability
To report a vulnerability contact this email ghyzhi36@gmail.com.

