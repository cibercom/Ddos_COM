# AKN DDOS
Notice this tool is for educational purposes
![Example Image](https://i.imgur.com/D9ZwvNA.png)
## 🧠Features
  -  HTTP Methods: GET, POST, PATCH, DELETE, HEAD, etc.
  -  SSH/SCP overload (via libcurl)
  -  FTP overload (via libcurl)
  - UDP flooder (custom implementation)
  - tor
 - Vpn
 - Mac changer
## How to use
### 1.Install all libcurl essentails
  <pre> <code> sudo apt update
  sudo apt install libcurl4-openssl-dev </code> </pre>
### 2.Install OpenVPN (for VPN routing feature)
  <pre> <code> sudo apt install openvpn -y</code> </pre>
### 3. Ensure Build Tools (like GCC) are installed
  <pre> <code> sudo apt install build-essential -y</code> </pre>
### 4. Install Tor
  <pre> <code> sudo apt install tor -y</code> </pre>
### 5.Download
<pre><code>git clone
https://github.com/thezaid1234/AKN_DDOS.git
cd AKN_DDOS
</pre></code>
### 6. ALlow
  <pre> <code> chmod +x DDOS</code> </pre>
### 7. Start tor
  <pre> <code>service tor start</code> </pre>
### 9. Mac changer install
  <pre><code>sudo apt install macchanger -y</code></pre>
### 10. Run
  <pre> <code>sudo ./DDOS</code> </pre>
### 11. If you want to use this for commercial uses or rexport or take ownership and take the code for it basically have full controll contact ghyzhi36@gmail.com.

### 12. Pls don't forget to add star if you like this tool. Enjoy!!
