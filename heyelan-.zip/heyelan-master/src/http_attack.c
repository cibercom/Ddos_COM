#include "http_attack.h"

void attack_http()
{
	return;
}
