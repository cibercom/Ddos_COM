#ifndef ICMP_ATTACK_H
#define ICMP_ATTACK_H

#include "types.h"

void attack_icmp(struct target_data *target);

#endif
