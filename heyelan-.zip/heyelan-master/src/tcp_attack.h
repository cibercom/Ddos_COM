#ifndef TCP_ATTACK_H
#define TCP_ATTACK_H

#include "types.h"

void attack_tcp(struct target_data *target);

#endif
