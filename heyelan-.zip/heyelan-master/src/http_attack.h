#ifndef HTTP_ATTACK_H
#define HTTP_ATTACK_H

void attack_http();

#endif
