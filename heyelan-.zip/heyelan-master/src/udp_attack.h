#ifndef UDP_ATTACK_H
#define UDP_ATTACK_H

#include "types.h"

void attack_udp(struct target_data *target);

#endif
