javascript:(function(){var b=document.getElementsByTagName('meta'),c=b.length,a;while(c--){a=b[c];if(a.name.toLowerCase()=='viewport'){a.parentNode.removeChild(a)}}})();
