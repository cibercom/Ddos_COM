

Compile with GCC (apt-get install gcc / yum install gcc)

