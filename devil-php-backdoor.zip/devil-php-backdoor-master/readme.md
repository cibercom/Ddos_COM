# Devil PHP Backdoor

### What is this ?
It is a simple PHP backdoor created for educational and learning purposes.

### Features
- File Manager [Browse, download and delete files, create files and folders, upload files]
- Web shell/terminal [Execute system commands using system(), shell_exec(), passthru(), exec(), popen() functions]
- System informations
- Obfuscated

### Login Details
- Username : NomanProdhan
- Password : NomanProdhan@KS

### Screenshots
![Login Screen](https://raw.githubusercontent.com/NomanProdhan/devil-php-backdoor/master/screenshots/devil_php_backdoor_login_screen.png)

![System Information](https://raw.githubusercontent.com/NomanProdhan/devil-php-backdoor/master/screenshots/devil_php_backdoor_system_info_screen.png)

![File Manager](https://raw.githubusercontent.com/NomanProdhan/devil-php-backdoor/master/screenshots/devil_php_backdoor_file_manager_screen.png)

![Terminal](https://raw.githubusercontent.com/NomanProdhan/devil-php-backdoor/master/screenshots/devil_php_backdoor_terminal_screen.png)


### Warning !!
This backdoor is for educational purposes. Do not use it for illegal activities.

### Follow Me ;P [If you want]
- Twitter @[NomanProdhan](https://twitter.com/nomanProdhan)
- YouTube @[nomanprodhan](https://www.youtube.com/c/NOMANPRODHAN)
- Websites [www.nomantheking.com](https://nomantheking.com) [www.nomanprodhan.com](https://nomanprodhan.com)

---

If you are a Cyber Security enthusiast and want to improve your skill, you can join our Hack Zone at [www.hack.knightsquad.org](https://hack.knightsquad.org/) or [www.kshackzone.com](https://kshackzone.com/)
