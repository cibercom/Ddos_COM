/*
 * Copyright (C) 2008 Remko Troncon
 */

#include "AutoUpdater.h"

AutoUpdater::~AutoUpdater()
{
}
